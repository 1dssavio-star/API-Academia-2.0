CREATE DATABASE IF NOT EXISTS mf_academia
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE mf_academia;

CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  senha VARCHAR(255) NOT NULL,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS planos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  descricao VARCHAR(255),
  preco DECIMAL(10,2) NOT NULL,
  duracao_dias INT NOT NULL,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS alunos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  telefone VARCHAR(30),
  data_nascimento DATE,
  plano_id INT,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_alunos_planos FOREIGN KEY (plano_id)
    REFERENCES planos(id) ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS treinos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  aluno_id INT NOT NULL,
  nome VARCHAR(120) NOT NULL,
  descricao TEXT,
  dia_semana VARCHAR(20),
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_treinos_alunos FOREIGN KEY (aluno_id)
    REFERENCES alunos(id) ON DELETE CASCADE ON UPDATE CASCADE
);

-- Crie o primeiro usuário pelo endpoint POST /api/auth/register.
-- A senha será armazenada com hash bcrypt, nunca em texto puro.
