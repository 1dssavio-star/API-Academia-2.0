# API Academia

API REST desenvolvida com Node.js, Express e MySQL para gerenciar alunos, planos e treinos.

## Tecnologias
Node.js, Express, MySQL, dotenv, bcrypt, jsonwebtoken, Axios e API externa wger.

## Instalação
1. Instale Node.js e MySQL (Wamp).
2. Abra o terminal na pasta do projeto.
3. Execute `npm install`.
4. Copie `.env.example` para `.env` e informe as credenciais locais do MySQL.
5. Importe `database.sql` no phpMyAdmin ou MySQL.
6. Execute `npm run dev`.

Servidor padrão: `http://localhost:3000`.

## Autenticação
Cadastre um usuário em `POST /api/auth/register`:
```json
{ "nome": "Administrador", "email": "admin@email.com", "senha": "123456" }
```
Faça login em `POST /api/auth/login`:
```json
{ "email": "admin@email.com", "senha": "123456" }
```
Copie o campo `token` da resposta. Nas rotas protegidas, envie o cabeçalho:
`Authorization: Bearer SEU_TOKEN`.

As senhas são armazenadas com hash bcrypt. Nunca coloque a senha original no banco.

## Rotas
Todas as rotas abaixo, exceto cadastro e login, exigem token JWT.

| Método | Rota | Função |
|---|---|---|
| GET | `/` | Verificar se a API está ativa |
| POST | `/api/auth/register` | Cadastrar usuário |
| POST | `/api/auth/login` | Fazer login |
| GET | `/api/alunos` | Listar alunos |
| GET | `/api/alunos/:id` | Consultar aluno |
| POST | `/api/alunos` | Cadastrar aluno |
| PUT | `/api/alunos/:id` | Atualizar aluno |
| DELETE | `/api/alunos/:id` | Excluir aluno |
| GET | `/api/planos` | Listar planos |
| GET | `/api/planos/:id` | Consultar plano |
| POST | `/api/planos` | Cadastrar plano |
| PUT | `/api/planos/:id` | Atualizar plano |
| DELETE | `/api/planos/:id` | Excluir plano |
| GET | `/api/treinos` | Listar treinos |
| GET | `/api/treinos/:id` | Consultar treino |
| POST | `/api/treinos` | Cadastrar treino |
| PUT | `/api/treinos/:id` | Atualizar treino |
| DELETE | `/api/treinos/:id` | Excluir treino |
| GET | `/api/exercicios?busca=peito` | Consultar exercícios na API wger |

## Exemplos de dados
Aluno:
```json
{
  "nome": "João Silva",
  "email": "joao@email.com",
  "telefone": "88999990000",
  "data_nascimento": "2005-05-10",
  "plano_id": 1
}
```
Plano:
```json
{
  "nome": "Mensal",
  "descricao": "Acesso à academia por um mês",
  "preco": 89.90,
  "duracao_dias": 30
}
```
Treino:
```json
{
  "aluno_id": 1,
  "nome": "Treino A - Peito",
  "descricao": "Supino, crucifixo e flexão",
  "dia_semana": "Segunda"
}
```

## API externa
A rota `/api/exercicios` consulta a API pública wger (`https://wger.de/api/v2/exerciseinfo/`) e pode receber o parâmetro opcional `busca`. Os exercícios retornados são dados externos; a API local não os cadastra automaticamente no MySQL.

## Segurança e observações
- O arquivo `.env` contém credenciais e não deve ser enviado ao GitHub.
- `.env.example` contém somente nomes e exemplos de variáveis.
- As rotas de alunos, planos, treinos e exercícios exigem autenticação.
- Para produção, use HTTPS, segredo JWT forte e validações adicionais.
