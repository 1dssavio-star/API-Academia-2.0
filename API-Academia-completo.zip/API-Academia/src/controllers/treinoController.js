const db = require("../config/database");

async function listar(req, res, next) {
  try {
    const [rows] = await db.execute(
      `SELECT t.*, a.nome AS aluno FROM treinos t
       INNER JOIN alunos a ON a.id = t.aluno_id ORDER BY t.id DESC`
    );
    res.json(rows);
  } catch (erro) { next(erro); }
}
async function buscarPorId(req, res, next) {
  try {
    const [rows] = await db.execute(
      `SELECT t.*, a.nome AS aluno FROM treinos t
       INNER JOIN alunos a ON a.id = t.aluno_id WHERE t.id = ?`,
      [req.params.id]
    );
    if (!rows.length) return res.status(404).json({ erro: "Treino não encontrado." });
    res.json(rows[0]);
  } catch (erro) { next(erro); }
}
async function criar(req, res, next) {
  try {
    const { aluno_id, nome, descricao = null, dia_semana = null } = req.body;
    if (!aluno_id || !nome) return res.status(400).json({ erro: "Aluno e nome do treino são obrigatórios." });
    const [r] = await db.execute(
      "INSERT INTO treinos (aluno_id, nome, descricao, dia_semana) VALUES (?, ?, ?, ?)",
      [aluno_id, nome.trim(), descricao, dia_semana]
    );
    res.status(201).json({ mensagem: "Treino cadastrado.", id: r.insertId });
  } catch (erro) {
    if (erro.code === "ER_NO_REFERENCED_ROW_2") return res.status(400).json({ erro: "O aluno informado não existe." });
    next(erro);
  }
}
async function atualizar(req, res, next) {
  try {
    const { aluno_id, nome, descricao = null, dia_semana = null } = req.body;
    if (!aluno_id || !nome) return res.status(400).json({ erro: "Aluno e nome do treino são obrigatórios." });
    const [r] = await db.execute(
      "UPDATE treinos SET aluno_id = ?, nome = ?, descricao = ?, dia_semana = ? WHERE id = ?",
      [aluno_id, nome.trim(), descricao, dia_semana, req.params.id]
    );
    if (!r.affectedRows) return res.status(404).json({ erro: "Treino não encontrado." });
    res.json({ mensagem: "Treino atualizado." });
  } catch (erro) {
    if (erro.code === "ER_NO_REFERENCED_ROW_2") return res.status(400).json({ erro: "O aluno informado não existe." });
    next(erro);
  }
}
async function excluir(req, res, next) {
  try {
    const [r] = await db.execute("DELETE FROM treinos WHERE id = ?", [req.params.id]);
    if (!r.affectedRows) return res.status(404).json({ erro: "Treino não encontrado." });
    res.json({ mensagem: "Treino excluído." });
  } catch (erro) { next(erro); }
}
module.exports = { listar, buscarPorId, criar, atualizar, excluir };
