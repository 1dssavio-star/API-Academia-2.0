const db = require("../config/database");

async function listar(req, res, next) {
  try {
    const [rows] = await db.execute("SELECT * FROM planos ORDER BY id DESC");
    res.json(rows);
  } catch (erro) { next(erro); }
}
async function buscarPorId(req, res, next) {
  try {
    const [rows] = await db.execute("SELECT * FROM planos WHERE id = ?", [req.params.id]);
    if (!rows.length) return res.status(404).json({ erro: "Plano não encontrado." });
    res.json(rows[0]);
  } catch (erro) { next(erro); }
}
async function criar(req, res, next) {
  try {
    const { nome, descricao = null, preco, duracao_dias } = req.body;
    if (!nome || preco === undefined || duracao_dias === undefined)
      return res.status(400).json({ erro: "Nome, preço e duração são obrigatórios." });
    if (!Number.isFinite(Number(preco)) || Number(preco) < 0 ||
        !Number.isInteger(Number(duracao_dias)) || Number(duracao_dias) <= 0)
      return res.status(400).json({ erro: "Preço ou duração inválidos." });
    const [r] = await db.execute(
      "INSERT INTO planos (nome, descricao, preco, duracao_dias) VALUES (?, ?, ?, ?)",
      [nome.trim(), descricao, Number(preco), Number(duracao_dias)]
    );
    res.status(201).json({ mensagem: "Plano cadastrado.", id: r.insertId });
  } catch (erro) { next(erro); }
}
async function atualizar(req, res, next) {
  try {
    const { nome, descricao = null, preco, duracao_dias } = req.body;
    if (!nome || preco === undefined || duracao_dias === undefined)
      return res.status(400).json({ erro: "Nome, preço e duração são obrigatórios." });
    if (!Number.isFinite(Number(preco)) || Number(preco) < 0 ||
        !Number.isInteger(Number(duracao_dias)) || Number(duracao_dias) <= 0)
      return res.status(400).json({ erro: "Preço ou duração inválidos." });
    const [r] = await db.execute(
      "UPDATE planos SET nome = ?, descricao = ?, preco = ?, duracao_dias = ? WHERE id = ?",
      [nome.trim(), descricao, Number(preco), Number(duracao_dias), req.params.id]
    );
    if (!r.affectedRows) return res.status(404).json({ erro: "Plano não encontrado." });
    res.json({ mensagem: "Plano atualizado." });
  } catch (erro) { next(erro); }
}
async function excluir(req, res, next) {
  try {
    const [r] = await db.execute("DELETE FROM planos WHERE id = ?", [req.params.id]);
    if (!r.affectedRows) return res.status(404).json({ erro: "Plano não encontrado." });
    res.json({ mensagem: "Plano excluído. Alunos vinculados ficam sem plano." });
  } catch (erro) { next(erro); }
}
module.exports = { listar, buscarPorId, criar, atualizar, excluir };
