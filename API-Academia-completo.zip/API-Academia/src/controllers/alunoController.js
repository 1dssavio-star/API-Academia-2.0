const db = require("../config/database");

async function listar(req, res, next) {
  try {
    const [rows] = await db.execute(
      `SELECT a.id, a.nome, a.email, a.telefone, a.data_nascimento, a.plano_id,
              p.nome AS plano
       FROM alunos a LEFT JOIN planos p ON p.id = a.plano_id ORDER BY a.id DESC`
    );
    res.json(rows);
  } catch (erro) { next(erro); }
}

async function buscarPorId(req, res, next) {
  try {
    const [rows] = await db.execute(
      `SELECT a.id, a.nome, a.email, a.telefone, a.data_nascimento, a.plano_id,
              p.nome AS plano
       FROM alunos a LEFT JOIN planos p ON p.id = a.plano_id WHERE a.id = ?`,
      [req.params.id]
    );
    if (!rows.length) return res.status(404).json({ erro: "Aluno não encontrado." });
    res.json(rows[0]);
  } catch (erro) { next(erro); }
}

async function criar(req, res, next) {
  try {
    const { nome, email, telefone = null, data_nascimento = null, plano_id = null } = req.body;
    if (!nome || !email) return res.status(400).json({ erro: "Nome e e-mail são obrigatórios." });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ erro: "E-mail inválido." });

    const [result] = await db.execute(
      "INSERT INTO alunos (nome, email, telefone, data_nascimento, plano_id) VALUES (?, ?, ?, ?, ?)",
      [nome.trim(), email.toLowerCase().trim(), telefone, data_nascimento, plano_id]
    );
    res.status(201).json({ mensagem: "Aluno cadastrado.", id: result.insertId });
  } catch (erro) {
    if (erro.code === "ER_DUP_ENTRY") return res.status(409).json({ erro: "Já existe aluno com este e-mail." });
    if (erro.code === "ER_NO_REFERENCED_ROW_2") return res.status(400).json({ erro: "O plano informado não existe." });
    next(erro);
  }
}

async function atualizar(req, res, next) {
  try {
    const { nome, email, telefone = null, data_nascimento = null, plano_id = null } = req.body;
    if (!nome || !email) return res.status(400).json({ erro: "Nome e e-mail são obrigatórios." });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ erro: "E-mail inválido." });

    const [result] = await db.execute(
      "UPDATE alunos SET nome = ?, email = ?, telefone = ?, data_nascimento = ?, plano_id = ? WHERE id = ?",
      [nome.trim(), email.toLowerCase().trim(), telefone, data_nascimento, plano_id, req.params.id]
    );
    if (!result.affectedRows) return res.status(404).json({ erro: "Aluno não encontrado." });
    res.json({ mensagem: "Aluno atualizado." });
  } catch (erro) {
    if (erro.code === "ER_DUP_ENTRY") return res.status(409).json({ erro: "Já existe aluno com este e-mail." });
    if (erro.code === "ER_NO_REFERENCED_ROW_2") return res.status(400).json({ erro: "O plano informado não existe." });
    next(erro);
  }
}

async function excluir(req, res, next) {
  try {
    const [result] = await db.execute("DELETE FROM alunos WHERE id = ?", [req.params.id]);
    if (!result.affectedRows) return res.status(404).json({ erro: "Aluno não encontrado." });
    res.json({ mensagem: "Aluno excluído." });
  } catch (erro) { next(erro); }
}

module.exports = { listar, buscarPorId, criar, atualizar, excluir };
