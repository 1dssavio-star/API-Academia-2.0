const { listarExercicios } = require("../services/exercicioService");

async function listar(req, res, next) {
  try {
    const exercicios = await listarExercicios(req.query.busca);
    res.json({
      fonte: "wger Workout Manager API",
      quantidade: exercicios.length,
      resultados: exercicios
    });
  } catch (erro) {
    erro.status = 502;
    erro.message = "Não foi possível consultar a API externa de exercícios.";
    next(erro);
  }
}

module.exports = { listar };
