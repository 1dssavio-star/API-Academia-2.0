const db = require("../config/database");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

async function cadastrar(req, res, next) {
  try {
    const { nome, email, senha } = req.body;
    if (!nome || !email || !senha) {
      return res.status(400).json({ erro: "Nome, e-mail e senha são obrigatórios." });
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return res.status(400).json({ erro: "Informe um e-mail válido." });
    }
    if (senha.length < 6) {
      return res.status(400).json({ erro: "A senha deve ter pelo menos 6 caracteres." });
    }

    const [existente] = await db.execute("SELECT id FROM usuarios WHERE email = ?", [email]);
    if (existente.length) return res.status(409).json({ erro: "Este e-mail já está cadastrado." });

    const hash = await bcrypt.hash(senha, 10);
    const [resultado] = await db.execute(
      "INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)",
      [nome.trim(), email.toLowerCase().trim(), hash]
    );
    return res.status(201).json({ mensagem: "Usuário cadastrado.", id: resultado.insertId });
  } catch (erro) { next(erro); }
}

async function login(req, res, next) {
  try {
    const { email, senha } = req.body;
    if (!email || !senha) return res.status(400).json({ erro: "E-mail e senha são obrigatórios." });

    const [usuarios] = await db.execute("SELECT * FROM usuarios WHERE email = ?", [email.toLowerCase().trim()]);
    if (!usuarios.length) return res.status(401).json({ erro: "E-mail ou senha incorretos." });

    const usuario = usuarios[0];
    const confere = await bcrypt.compare(senha, usuario.senha);
    if (!confere) return res.status(401).json({ erro: "E-mail ou senha incorretos." });

    const token = jwt.sign(
      { id: usuario.id, nome: usuario.nome, email: usuario.email },
      process.env.JWT_SECRET,
      { expiresIn: "8h" }
    );
    return res.json({
      mensagem: "Login realizado com sucesso.",
      token,
      usuario: { id: usuario.id, nome: usuario.nome, email: usuario.email }
    });
  } catch (erro) { next(erro); }
}

module.exports = { cadastrar, login };
