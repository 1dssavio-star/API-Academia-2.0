const axios = require("axios");

const apiExterna = axios.create({
  baseURL: "https://wger.de/api/v2",
  timeout: 10000,
  headers: { Accept: "application/json" }
});

async function listarExercicios(termo) {
  // A wger disponibiliza a consulta pública de informações de exercícios.
  const resposta = await apiExterna.get("/exerciseinfo/", {
    params: { limit: 20, format: "json" }
  });

  const resultados = (resposta.data.results || []).map(item => {
    const traducao = (item.translations || []).find(t => t.language === 2)
      || (item.translations || [])[0]
      || {};

    return {
      id: item.id,
      nome: traducao.name || item.name || "Exercício sem nome",
      descricao: traducao.description || item.description || "",
      categoria: item.category || null,
      equipamento: item.equipment || [],
      musculos: item.muscles || []
    };
  });

  if (!termo) return resultados;
  const busca = termo.toLowerCase();
  return resultados.filter(item =>
    item.nome.toLowerCase().includes(busca) ||
    item.descricao.toLowerCase().includes(busca)
  );
}

module.exports = { listarExercicios };
