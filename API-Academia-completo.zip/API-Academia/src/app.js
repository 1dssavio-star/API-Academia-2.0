const express = require("express");
const cors = require("cors");
const autenticar = require("./middlewares/authMiddleware");

const app = express();

app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
  res.json({ mensagem: "API Academia funcionando!" });
});

app.use("/api/auth", require("./routes/authRoutes"));

// Rotas protegidas: é necessário enviar Authorization: Bearer <token>.
app.use("/api/alunos", autenticar, require("./routes/alunoRoutes"));
app.use("/api/planos", autenticar, require("./routes/planoRoutes"));
app.use("/api/treinos", autenticar, require("./routes/treinoRoutes"));
app.use("/api/exercicios", autenticar, require("./routes/exercicioRoutes"));

app.use((req, res) => {
  res.status(404).json({ erro: "Rota não encontrada." });
});

app.use((erro, req, res, next) => {
  console.error(erro);
  const status = erro.status || 500;
  res.status(status).json({
    erro: status === 500 ? "Erro interno do servidor." : erro.message
  });
});

module.exports = app;
