const router = require("express").Router();
const controller = require("../controllers/exercicioController");

router.get("/", controller.listar);

module.exports = router;
