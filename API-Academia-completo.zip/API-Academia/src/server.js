require("dotenv").config();

if (!process.env.JWT_SECRET) {
  console.error("Configure JWT_SECRET no arquivo .env.");
  process.exit(1);
}

const app = require("./app");
const db = require("./config/database");
const PORT = process.env.PORT || 3000;

async function iniciarServidor() {
  try {
    await db.query("SELECT 1");
    console.log("Conexão com MySQL realizada com sucesso.");
    app.listen(PORT, () => console.log(`API rodando em http://localhost:${PORT}`));
  } catch (erro) {
    console.error("Erro na conexão com o banco:", erro.message);
    process.exit(1);
  }
}

iniciarServidor();
